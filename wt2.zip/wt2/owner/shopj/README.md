# Shopping-Cart-in-AngularJS

Tools and Technologies

    Technology: HTML, Bootstrap, CSS, Angular js, Json, , Drag & Drop, Progressive Web Application.
    Database : json .

This Projects covers all fundamentals of Angular

    Multiple Modules
    Components, Template and DataBinding
    Form Validation
    HttpClient
    Animations
    Dependency Injection
    Routing & Navigation
    Service Workers
    Pipes
    Gaurds etc..
    https://raw.githubusercontent.com/sobuz80/Shopping-Cart-in-AngularJS/master/Capture1.
    
    https://raw.githubusercontent.com/sobuz80/Shopping-Cart-in-AngularJS/master/Capture2.PNG
    
